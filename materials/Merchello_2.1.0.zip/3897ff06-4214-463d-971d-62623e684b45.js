/*! MerchelloPaymentProviders
 * https://github.com/Merchello/Merchello
 * Copyright (c) 2016 Across the Pond, LLC.
 * Licensed MIT
 */

(function() { 



})();